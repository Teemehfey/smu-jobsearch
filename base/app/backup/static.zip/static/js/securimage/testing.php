<nav>
		<ul style="width:960px; margin-top:-15px; margin-left:170px; z-index:5;">
				
			<li><a href="index.html">Home</a></li>
			<li><a href="about.html">About Global Hearts</a>
				<ul>
					<li><a href="index.php.html">Mentally Disadvantaged</a></li>
					<li><a href="pd.html">Physically Disadvantaged</a></li>
					<li><a href="sd.html">Income Inequality Disadvantaged</a></li>
					<li><a href="ed.html">Education Disadvantaged</a></li>
					<li><a href="emd.html">Employment Disadvantaged</a></li>
				</ul>
			</li>
			<li><a href="chatbox.html">Chat Box</a></li>
			<li><a href="main.php">Gallery</a></li>
			<li><a href="donation form.html">Donation</a>
			<li><a href="event.html">Events</a>
				  
		</ul>
	</nav>